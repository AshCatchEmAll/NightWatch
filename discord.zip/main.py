import os
from keep_alive import keep_alive
from discord.ext import commands
import discord
import requests
import json
import datetime as dt
from pytz import timezone
from skyfield import almanac
from skyfield.api import N, W, wgs84, load
client = discord.Client()
bot = commands.Bot(
	command_prefix="!",  
	case_insensitive=True  
)
 
commands = {"**#Hello**":"Greet NightWatch!","#motivate":"Need for motivation? NightWatch got your back.","#bodies -p <pageNumber 1-26>":"Get available body names","#bodies -id <bodyName>":"Get info on specified body","#horoscope -t <sign>":"Get today's horoscope for specified sign","#horoscope -m <sign>":"Get month's horoscope for specified sign","#viewtime":"Know when it will be dark enough to see the stars","#calender <month>":"Astronomical Events for specified month","#elon":"Surprise for all gamers out there"}
@bot.event 
async def on_ready():  
    print("I'm in")
    print(bot.user) 

@client.event
async def on_message(message):
	if message.author == client.user:
		return
	elif message.content.startswith("#commands"):
		embed = discord.Embed(title="All Commands")
		for k,v in commands.items():
			embed.add_field(name=k,value=v,inline=False)
		await message.channel.send(embed=embed)
	elif message.content.startswith("#Hello"):
		await message.channel.send("Hello " + str(message.author).split("#")[0] +  " !")


	elif message.content.startswith("#motivate"):
		response = requests.get("https://mountainNode.username.repl.co/api/validate/motivate")
		jsonData = response.json()["motivate"]
		jsonData = json.loads(jsonData)
		quote = jsonData[0]['q']+" - "+jsonData[0]['a']
		await message.channel.send(quote)



	elif message.content.startswith("#bodies -p"):
		msg = await message.channel.send("Please wait, your request is travelling accross servers...✨")
		print("gg")
		page = int(str(message.content).split("-p")[1].strip())
		myobj = {'page': page}
		response = requests.post("https://mountainNode.username.repl.co/api/validate/page",json=myobj)
		if(response.status_code!=200):
			await message.channel.send("Page number can be in range [1-26]")
			return
		response = response.json()
		start = response["start"]
		end = response["end"]
	
		body = json.loads(response["body"])
		names = []
		for i in range(start,end+1):
			names.append(body[i]["englishName"])
		await msg.delete()
		jsonData = json.dumps(names, indent=2)
	
		await message.channel.send(jsonData)





	elif message.content.startswith("#bodies -id"):
		msg = await message.channel.send("Please wait, your request is travelling accross servers...✨")
		id = str(message.content).split("-id")[1].strip()
		myobj = {'id': id}
		response = requests.post("https://mountainNode.username.repl.co/api/validate/id",json=myobj)
		if(response.status_code!=200):
			await msg.delete()
			await message.channel.send("Something went wrong, please check your input")		
			return
		response = response.json()
		
		bodies = json.loads(response["body"])
		value = next((x for x in bodies if x["englishName"] == (str(id)).strip().capitalize()), None)
		await msg.delete()
		if(value==None):
			
			return 	await message.channel.send("Body with that name not found")
		else:
			value = json.dumps(value, indent=4)
			return await message.channel.send(value)







	elif message.content.startswith("#horoscope -t"):
		msg = await message.channel.send("Please wait, your request is travelling accross servers...✨")
		sign = str(message.content).split("-t")[1]
		
		sign = (str(sign)).strip().capitalize()
		myobj = {'sign': sign}
		response = requests.post("https://mountainNode.username.repl.co/api/validate/today",json=myobj)	
		jsonData = response.json()
		value = jsonData["horoscope"]
		if(value==None):
			await msg.delete()
			return 	await message.channel.send("Something went wrong")
		else:
			await msg.delete()
			value = json.dumps(value, indent=4)
			embed = discord.Embed(title=f"Today's Horoscope for {sign}",description=value)
			return await message.channel.send(embed=embed)





	elif message.content.startswith("#horoscope -m"):
		msg = await message.channel.send("Please wait, your request is travelling accross servers...✨")
		sign = str(message.content).split("-m")[1]
		
		sign = (str(sign)).strip().capitalize()
		myobj = {'sign': sign}
		response = requests.post("https://mountainNode.username.repl.co/api/validate/month",json=myobj)	
		jsonData = response.json()
		value = jsonData["horoscope"]
		if(value==None):
			await msg.delete()
			return 	await message.channel.send("Something went wrong")
		else:
			await msg.delete()
			embed = discord.Embed(title=f"Month Horoscope for {sign}",description=value)
			return await message.channel.send(embed=embed)





	elif message.content.startswith("#viewtime"):
		zone = timezone('US/Eastern')
		now = zone.localize(dt.datetime.now())
		midnight = now.replace(hour=0, minute=0, second=0, microsecond=0)
		next_midnight = midnight + dt.timedelta(days=1)

		ts = load.timescale()
		t0 = ts.from_datetime(midnight)
		t1 = ts.from_datetime(next_midnight)
		eph = load('de421.bsp')
		bluffton = wgs84.latlon(40.8939 * N, 83.8917 * W)
		f = almanac.dark_twilight_day(eph, bluffton)
		times, events = almanac.find_discrete(t0, t1, f)
		tstr=""
		for t, e in zip(times, events):
				tstr = tstr + f"{str(t.astimezone(zone))[:16]} {almanac.TWILIGHTS[e]}" + "\n"
		return await message.channel.send(tstr)






	elif message.content.startswith("#calender"):
		msg = await message.channel.send("Please wait, your request is travelling accross servers...✨")
		month = str(message.content).split(" ")[1]
		myobj = {'month': month}
		response = requests.post("https://mountainNode.username.repl.co/api/validate/calender",json=myobj)	
		if(response.status_code!=200):
			await msg.delete()
			return 	await message.channel.send("Something went wrong")
		try:
			await msg.delete()
			with open(f'images/{month}.jpg', 'rb') as f:
				picture = discord.File(f)	
				await message.channel.send(f"**Here are Astronomical event for {month.capitalize()} 2021**",file=picture)		
		except FileNotFoundError:
				await message.channel.send("Invalid month name. Valid month names are\njan,feb,march,april,may,june,july,aug,sept,oct,nov,dec")	





	elif message.content.startswith("#elon"):
			with open('elon.png', 'rb') as f:
				picture = discord.File(f)	
				await message.channel.send("Elon",file=picture)	



extensions = [
	'cogs.cog_example'  
]


if __name__ == '__main__':  
  client.run(os.getenv("TOKEN"))
  for extension in extensions:
    bot.load_extension(extension)  
    
keep_alive() 
token = os.environ.get("DISCORD_BOT_SECRET") 
bot.run(token) 