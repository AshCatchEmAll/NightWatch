package main

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	// "github.com/justinas/alice"
)

type Horoscope struct {
	Horoscope string `json:"horoscope,omitempty"`
	Sign      string `json:"sign,omitempty"`
}

func allBody(w http.ResponseWriter, r *http.Request) {

	resp, err := http.Get("https://api.le-systeme-solaire.net/rest.php/bodies/")
	if err != nil {
		log.Fatalln(err)
	}
	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Fatalln(err)
	}

	sb := string(body)
	log.Printf(sb)
	json.NewEncoder(w).Encode(string(sb))
	return
}

func horoscopeT(w http.ResponseWriter, r *http.Request) {

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		log.Fatalln(err)
	}
	var h Horoscope

	err = json.Unmarshal(body, &h)
	if err != nil {
		log.Fatalln(err)
	}

	url := "http://horoscope-api.herokuapp.com/horoscope/today/" + h.Sign

	resp, errr := http.Get(url)
	if errr != nil {
		fmt.Println("h")
		log.Fatalln(errr)
	}
	body, erro := ioutil.ReadAll(resp.Body)
	if erro != nil {
		log.Fatalln(erro)
	}

	sb := string(body)
	log.Printf(sb)
	json.NewEncoder(w).Encode(string(sb))
	return
}

func horoscopeM(w http.ResponseWriter, r *http.Request) {

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		log.Fatalln(err)
	}
	var h Horoscope

	err = json.Unmarshal(body, &h)
	if err != nil {
		log.Fatalln(err)
	}

	url := "http://horoscope-api.herokuapp.com/horoscope/month/" + h.Sign
	fmt.Println(url)
	resp, errr := http.Get(url)
	if errr != nil {
		fmt.Println("h")
		log.Fatalln(errr)
	}
	body, erro := ioutil.ReadAll(resp.Body)
	if erro != nil {
		log.Fatalln(erro)
	}

	sb := string(body)
	log.Printf(sb)
	json.NewEncoder(w).Encode(string(sb))
	return
}

func motivate(w http.ResponseWriter, r *http.Request) {

	resp, errr := http.Get("https://zenquotes.io/api/random")
	if errr != nil {
		fmt.Println("h")
		log.Fatalln(errr)
	}
	body, erro := ioutil.ReadAll(resp.Body)
	if erro != nil {
		log.Fatalln(erro)
	}

	sb := string(body)
	log.Printf(sb)
	json.NewEncoder(w).Encode(string(sb))
	return
}
