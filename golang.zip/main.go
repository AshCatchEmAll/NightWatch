package main

import (
	"log"
	"net/http"
	"os"

)



func main() {

	infoLog := log.New(os.Stdout, "INFO\t", log.Ldate|log.Ltime)
	errorLog := log.New(os.Stderr, "ERROR\t", log.Ldate|log.Ltime|log.Lshortfile)
	mux := http.NewServeMux()
	mux.HandleFunc("/allBody", allBody)
	mux.HandleFunc("/today", horoscopeT)
	mux.HandleFunc("/month", horoscopeM)
	mux.HandleFunc("/motivate", motivate)
	server := &http.Server{
		Addr:     ":8080",
		ErrorLog: errorLog,
		Handler:  mux,
	}
	infoLog.Println("Listening on server :8080")
	err := server.ListenAndServe()
	errorLog.Fatal(err)
 
}