const express = require("express");
const app = express();
const bodyParser = require("body-parser");

const validateRouter = require("./router/validate.js")

app.use((req, res, next) => {
    //TODO:Change allow origin to our website only 
    res.setHeader("Access-Control-Allow-Origin", "*")
    res.setHeader("Access-Control-Allow-Headers", "Accept,Origin,X-Requested-With,Content-Type,Authorization,CSRF-TOKEN")
    res.setHeader("Access-Control-Allow-Methods", "GET,POST,DELETE,PATCH")
    next();
})


app.use(bodyParser.urlencoded({ extended: false }))

app.use(bodyParser.json())

app.use("/api/validate",validateRouter)

app.use((err,req,res,next)=>{
    
    if(res.headerSend){
        return next(err)
    }else{
        console.log("err catcher", err.message);
        if (err.message) {
            res.status(500).json({ message: err.message })
        } else {
            res.status(500).json({ message: "Server error occured" })
        }
    }

})


app.listen("5000",(err)=>{
        if(err){
            console.log(err,"Listening error")
        }else{
            console.log("Listening at 5000...")
        }
    })