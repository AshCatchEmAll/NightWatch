const express = require("express");
const router = express.Router();
const { check } = require('express-validator');
const {pageController,idController,horoscopeTController,horoscopeMController,calenderController,motivateController} = require("../controller/controller.js")

router.post("/page",[
    check("page").isNumeric(),
    


],pageController)

router.post("/id",[
	check("id").isString()
],idController)
module.exports = router;


router.post("/today",[
	check("sign").isString()
],horoscopeTController)
module.exports = router;


router.post("/month",[
	check("sign").isString()
],horoscopeMController)


router.post("/calender",[
	check("month").isString()
],calenderController)


router.get("/motivate",[

],motivateController)

module.exports = router;


