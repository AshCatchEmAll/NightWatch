const { validationResult } = require('express-validator');
const https = require('https')
const axios = require('axios');


//Page controller
const pageController = async (req, res, next) => {

	const errors = validationResult(req);
	if (!errors.isEmpty()) {
		console.log(errors.array())
		return res.status(400).json({ message: errors.array() })
	}
	const { page } = req.body;

	try {
		pageSize = 10
		if (page < 1 || page > 26) {
			return res.status(404).send({ message: "Invalid page number" })
		}

		start = (page - 1) * 10
		end = (pageSize - 1) + (pageSize * (page - 1))
		axios.get('https://mountaingo.username.repl.co/allBody')
			.then(resp => {


				;
				if (resp.status !== 200) {
					res.status(400).json({ message: "something went wrong" })
				}
				const body = JSON.parse(resp.data);


				res.status(200).json({ "message": "Req good", "body": JSON.stringify(body["bodies"]), start, end })
			})
			.catch(err => {
				console.log('Error: ', err.message);
			});


	} catch (error) {
		next(new Error(error))
	}
}


const idController = async (req, res, next) => {

	const errors = validationResult(req);
	if (!errors.isEmpty()) {
		console.log(errors.array())
		return res.status(400).json({ message: errors.array() })
	}
	const { id } = req.body;
	try {
		axios.get('https://mountaingo.username.repl.co/allBody')
			.then(resp => {



				if (resp.status !== 200) {
					return res.status(400).json({ message: "something went wrong" })
				}
				const body = JSON.parse(resp.data);


				res.status(200).json({ "message": "Req good", "body": JSON.stringify(body["bodies"]) })
			})
			.catch(err => {
				console.log('Error: ', err.message);
			});
	} catch (error) {
		next(new Error(error))
	}
}

//Horoscope controller
const horoscopeTController = async (req, res, next) => {
	const errors = validationResult(req);
	if (!errors.isEmpty()) {
		console.log(errors.array())
		return res.status(400).json({ message: errors.array() })
	}
	const { sign } = req.body;
	try {
		axios.post('https://mountaingo.username.repl.co/today', { sign: sign })
			.then(resp => {

				console.log('Status Code:', resp.status);
				;
				if (resp.status !== 200) {
					return res.status(400).json({ message: "something went wrong" })
				}
				const body = JSON.parse(resp.data);


				res.status(200).json({ "message": "Req good", "horoscope": JSON.stringify(body["horoscope"]) })
			})
			.catch(err => {
				console.log('Error: ', err.message);
			});
	} catch (error) {
		next(new Error(error))
	}
}

const horoscopeMController = async (req, res, next) => {
	const errors = validationResult(req);
	if (!errors.isEmpty()) {
		console.log(errors.array())
		return res.status(400).json({ message: errors.array() })
	}
	const { sign } = req.body;
	try {
		axios.post('https://mountaingo.username.repl.co/month', { sign: sign })
			.then(resp => {


				if (resp.status !== 200) {
					return res.status(400).json({ message: "something went wrong" })
				}
				const body = JSON.parse(resp.data);


				res.status(200).json({ "message": "Req good", "horoscope": JSON.stringify(body["horoscope"]) })
			})
			.catch(err => {
				console.log('Error: ', err.message);
			});
	} catch (error) {
		next(new Error(error))
	}
}


const calenderController = async (req, res, next) => {
	console.log("calender check")
	const errors = validationResult(req);
	if (!errors.isEmpty()) {
		console.log(errors.array())
		return res.status(400).json({ message: errors.array() })
	}
	const { month } = req.body;
	const months = ["jan", "feb", "march", "april", "may", "june", "july", "aug", "sept", "oct", "nov", "dec"]
	if (months.includes(month)) {
		return res.status(200).json({ message: "req good" })
	} else {
		return res.status(400).json({ message: "something went wrong" })
	}

}


const motivateController = async (req, res, next) => {
	console.log("motivate check")
	const errors = validationResult(req);
	if (!errors.isEmpty()) {
		console.log(errors.array())
		return res.status(400).json({ message: errors.array() })
	}
	try {
		axios.get('https://mountaingo.username.repl.co/motivate')
			.then(resp => {



				if (resp.status !== 200) {
					return res.status(400).json({ message: "something went wrong" })
				}
				const body = JSON.parse(resp.data);
				res.status(200).json({ "message": "Req good", "motivate": JSON.stringify(body) })
			})
			.catch(err => {
				console.log('Error: ', err.message);
			});
	} catch (error) {
		next(new Error(error))
	}

}
exports.pageController = pageController;
exports.idController = idController;
exports.horoscopeTController = horoscopeTController;
exports.horoscopeMController = horoscopeMController;
exports.calenderController = calenderController;
exports.motivateController = motivateController;